import os
import io
import tempfile
import requests
from datetime import datetime

import pdfkit
from flask import render_template

def get_exchange_rate():
    """Get the exchange rate from JPY to GBP"""
    # Default fallback value if API fails
    default_rate = 0.0053  # Approximate JPY to GBP rate
    
    try:
        response = requests.get('https://api.exchangerate-api.com/v4/latest/JPY')
        data = response.json()
        return data['rates']['GBP']
    except Exception as e:
        print(f"Error getting exchange rate: {e}")
        return default_rate

def generate_invoice_pdf(sale, customer, car):
    """Generate a PDF invoice for a sale"""
    # Render the invoice template to HTML
    rendered_html = render_template(
        'invoices/pdf_template.html',
        sale=sale,
        customer=customer,
        car=car,
        sale_date=sale.sale_date.strftime('%d-%m-%Y'),
        selling_price=round(sale.selling_price, 2),
        amount_received=round(sale.amount_received, 2),
        remaining_amount=round(sale.get_remaining_amount(), 2)
    )
    
    # PDF options
    options = {
        'page-size': 'A4',
        'margin-top': '0.75in',
        'margin-right': '0.75in',
        'margin-bottom': '0.75in',
        'margin-left': '0.75in',
        'encoding': 'UTF-8',
    }
    
    # Create a temporary file for the PDF
    with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as temp_pdf:
        # Generate PDF
        pdfkit.from_string(rendered_html, temp_pdf.name, options=options)
        
        # Read the PDF content
        with open(temp_pdf.name, 'rb') as pdf_file:
            pdf_content = pdf_file.read()
            
    # Clean up the temporary file
    os.unlink(temp_pdf.name)
    
    return pdf_content

def calculate_gbp_from_yen(amount_yen, exchange_rate):
    """Convert an amount in Japanese Yen to British Pounds"""
    return round(amount_yen * exchange_rate, 2)

def calculate_total_cost(auction_price_gbp, initial_payment_gbp, port_charges_gbp, 
                         inspection_charges_gbp, final_payment_gbp):
    """Calculate the total cost of a car in GBP"""
    return round(auction_price_gbp + port_charges_gbp + inspection_charges_gbp + final_payment_gbp, 2)

def format_currency(value, currency="GBP"):
    """Format a value as currency"""
    if currency == "GBP":
        return f"£{value:,.2f}"
    elif currency == "JPY":
        return f"¥{int(value):,}"
    return f"{value:,.2f}"