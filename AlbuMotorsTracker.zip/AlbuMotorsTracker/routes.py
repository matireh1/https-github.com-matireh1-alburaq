import os
import io
from datetime import datetime
from functools import wraps
from urllib.parse import urlparse

from flask import render_template, flash, redirect, url_for, request, session, jsonify, send_file, abort
from flask_login import login_user, logout_user, current_user, login_required

from app import app, db
from models import User, Car, Customer, Sale
from forms import LoginForm, CarForm, CustomerForm, SaleForm, InvoiceForm
from utils import get_exchange_rate, calculate_gbp_from_yen, calculate_total_cost, format_currency, generate_invoice_pdf

# Custom filters
@app.template_filter('currency')
def currency_filter(value, currency="GBP"):
    return format_currency(value, currency)

@app.template_filter('date')
def date_filter(value):
    if value is None:
        return ""
    if isinstance(value, str):
        try:
            value = datetime.strptime(value, '%Y-%m-%d').date()
        except ValueError:
            return value
    if isinstance(value, datetime):
        return value.strftime('%d-%m-%Y')
    return value

# Role-based access control
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.is_anonymous or not current_user.is_admin:
            flash('You need admin privileges to access this page.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

# Routes

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password', 'danger')
            return redirect(url_for('login'))
            
        login_user(user)
        next_page = request.args.get('next')
        if not next_page or urlparse(next_page).netloc != '':
            next_page = url_for('dashboard')
            
        flash(f'Welcome back, {user.username}!', 'success')
        return redirect(next_page)
        
    return render_template('login.html', title='Admin Login', form=form)



@app.route('/logout')
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Admin dashboard with financial information
    cars_count = Car.query.count()
    available_cars = Car.query.filter_by(status='Available').count()
    sold_cars = Car.query.filter_by(status='Sold').count()
    
    # Calculate total profit 
    total_profit = 0
    sales = Sale.query.all()
    for sale in sales:
        total_profit += sale.calculate_profit()
    
    # Get recent sales
    recent_sales = Sale.query.order_by(Sale.sale_date.desc()).limit(5).all()
    
    return render_template('dashboard.html', 
                          title='Burraq Motors Dashboard',
                          cars_count=cars_count,
                          available_cars=available_cars,
                          sold_cars=sold_cars,
                          total_profit=total_profit,
                          recent_sales=recent_sales,
                          Car=Car)

# Car routes - accessible by both admin and employee
@app.route('/cars')
@login_required
def cars_index():
    cars = Car.query.order_by(Car.created_at.desc()).all()
    return render_template('cars/index.html', title='Cars', cars=cars)

@app.route('/cars/add', methods=['GET', 'POST'])
@login_required
def add_car():
    form = CarForm()
    
    # Get current exchange rate
    exchange_rate = get_exchange_rate()
    form.exchange_rate.data = exchange_rate
    
    if form.validate_on_submit():
        # Calculate GBP values
        auction_price_gbp = calculate_gbp_from_yen(form.auction_price_yen.data, form.exchange_rate.data)
        initial_payment_gbp = calculate_gbp_from_yen(form.initial_payment_yen.data, form.exchange_rate.data)
        
        # Calculate total cost
        total_cost_gbp = calculate_total_cost(
            auction_price_gbp,
            initial_payment_gbp,
            form.port_charges_gbp.data,
            form.inspection_charges_gbp.data,
            form.final_payment_gbp.data
        )
        
        car = Car()
        car.car_name = form.car_name.data
        car.vin = form.vin.data
        car.auction_id = form.auction_id.data
        car.auction_price_yen = form.auction_price_yen.data
        car.initial_payment_yen = form.initial_payment_yen.data
        car.port_charges_gbp = form.port_charges_gbp.data
        car.inspection_charges_gbp = form.inspection_charges_gbp.data
        car.final_payment_gbp = form.final_payment_gbp.data
        car.exchange_rate = form.exchange_rate.data
        car.auction_price_gbp = auction_price_gbp
        car.initial_payment_gbp = initial_payment_gbp
        car.total_cost_gbp = total_cost_gbp
        car.status = 'Available'
        
        db.session.add(car)
        db.session.commit()
        
        flash('Car added successfully!', 'success')
        return redirect(url_for('cars_index'))
        
    return render_template('cars/add.html', title='Add Car', form=form)

@app.route('/cars/<int:id>')
@login_required
def view_car(id):
    car = Car.query.get_or_404(id)
    return render_template('cars/view.html', title=f'Car: {car.car_name}', car=car)

# Customer routes - admin only
@app.route('/customers')
@login_required
@admin_required
def customers_index():
    customers = Customer.query.all()
    return render_template('customers/index.html', title='Customers', customers=customers)

@app.route('/customers/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_customer():
    form = CustomerForm()
    
    if form.validate_on_submit():
        customer = Customer()
        customer.name = form.name.data
        customer.contact_info = form.contact_info.data
        customer.date_of_birth = form.date_of_birth.data
        
        db.session.add(customer)
        db.session.commit()
        
        flash('Customer added successfully!', 'success')
        return redirect(url_for('customers_index'))
        
    return render_template('customers/add.html', title='Add Customer', form=form)

@app.route('/customers/<int:id>')
@login_required
@admin_required
def view_customer(id):
    customer = Customer.query.get_or_404(id)
    sales = Sale.query.filter_by(customer_id=customer.id).all()
    return render_template('customers/view.html', title=f'Customer: {customer.name}', 
                          customer=customer, sales=sales)

# Sales routes - admin only
@app.route('/sales')
@login_required
@admin_required
def sales_index():
    sales = Sale.query.order_by(Sale.sale_date.desc()).all()
    return render_template('sales/index.html', title='Sales', sales=sales)

@app.route('/sales/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_sale():
    form = SaleForm()
    
    # Populate car choices (only available cars)
    form.car_id.choices = [(c.id, f"{c.car_name} ({c.vin})") 
                           for c in Car.query.filter_by(status='Available').all()]
    
    # Populate customer choices
    form.customer_id.choices = [(c.id, c.name) 
                               for c in Customer.query.all()]
    
    if form.validate_on_submit():
        # Check if car is available
        car = Car.query.get(form.car_id.data)
        if car.status != 'Available':
            flash('This car is not available for sale.', 'danger')
            return redirect(url_for('add_sale'))
        
        # Create the sale
        sale = Sale()
        sale.car_id = form.car_id.data
        sale.customer_id = form.customer_id.data
        sale.selling_price = form.selling_price.data
        sale.payment_type = form.payment_type.data
        sale.amount_received = form.amount_received.data
        sale.sale_date = form.sale_date.data
        
        # Update car status
        car.status = 'Sold'
        
        db.session.add(sale)
        db.session.commit()
        
        flash('Sale recorded successfully!', 'success')
        return redirect(url_for('view_sale', id=sale.id))
    
    # Check if there are available cars and customers
    if not form.car_id.choices:
        flash('No cars available for sale. Add a car first.', 'warning')
        return redirect(url_for('add_car'))
        
    if not form.customer_id.choices:
        flash('No customers in the system. Add a customer first.', 'warning')
        return redirect(url_for('add_customer'))
    
    return render_template('sales/add.html', title='Record Sale', form=form)

@app.route('/sales/<int:id>')
@login_required
@admin_required
def view_sale(id):
    sale = Sale.query.get_or_404(id)
    car = Car.query.get(sale.car_id)
    customer = Customer.query.get(sale.customer_id)
    
    return render_template('sales/view.html', title=f'Sale #{sale.id}', 
                          sale=sale, car=car, customer=customer)

# Invoice routes - admin only
@app.route('/invoices')
@login_required
@admin_required
def invoices_index():
    sales = Sale.query.order_by(Sale.sale_date.desc()).all()
    return render_template('invoices/index.html', title='Invoices', sales=sales)

@app.route('/invoices/generate/<int:sale_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def generate_invoice(sale_id):
    sale = Sale.query.get_or_404(sale_id)
    car = Car.query.get(sale.car_id)
    customer = Customer.query.get(sale.customer_id)
    
    return render_template('invoices/generate.html', title='Generate Invoice',
                          sale=sale, car=car, customer=customer)

@app.route('/invoices/download/<int:sale_id>')
@login_required
@admin_required
def download_invoice(sale_id):
    sale = Sale.query.get_or_404(sale_id)
    car = Car.query.get(sale.car_id)
    customer = Customer.query.get(sale.customer_id)
    
    # Generate the PDF
    try:
        pdf_data = generate_invoice_pdf(sale, customer, car)
        
        # Return the PDF as a downloadable file
        filename = f"invoice_{sale.id}_{customer.name.replace(' ', '_')}.pdf"
        return send_file(
            io.BytesIO(pdf_data),
            mimetype='application/pdf',
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        flash(f'Error generating invoice: {str(e)}', 'danger')
        return redirect(url_for('view_sale', id=sale_id))

# API routes
@app.route('/api/exchange-rate', methods=['GET'])
def api_exchange_rate():
    """Get the current exchange rate from JPY to GBP"""
    rate = get_exchange_rate()
    return jsonify({'rate': rate})