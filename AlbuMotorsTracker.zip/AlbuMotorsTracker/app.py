import os
import logging
from datetime import datetime

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from flask_login import LoginManager

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
# create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "burraq-motors-manchester-secret-key")

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Set up login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'

# Initialize the app with the extension
db.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# Create database tables
with app.app_context():
    from models import User, Car, Customer, Sale
    db.create_all()
    
    # Initialize the admin user if it doesn't exist
    admin = User.query.filter_by(username='tasawar').first()
    if not admin:
        admin = User()
        admin.username = 'tasawar'
        admin.email = 'admin@burraqmotors.com'
        admin.is_admin = True
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()
        print("Admin user created: tasawar")
    
# Import routes after the db is initialized
from routes import *