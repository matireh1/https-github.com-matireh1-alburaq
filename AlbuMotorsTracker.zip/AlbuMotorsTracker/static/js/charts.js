/**
 * Alburaq Motors Management System - Charts
 * 
 * This file contains functions for creating and managing charts 
 * using Chart.js throughout the application.
 */

/**
 * Create a bar chart comparing sales and profits
 * @param {string} elementId - Canvas element ID
 * @param {Array} salesData - Array of sales data points
 * @param {Array} profitData - Array of profit data points
 */
function createSalesVsProfitChart(elementId, salesData, profitData) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    // Extract labels and values
    const labels = salesData.map(item => item.month);
    const salesValues = salesData.map(item => item.value);
    const profitValues = profitData.map(item => item.value);
    
    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Sales',
                    data: salesValues,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Profit',
                    data: profitValues,
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '£' + value.toLocaleString();
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += '£' + context.parsed.y.toLocaleString();
                            return label;
                        }
                    }
                },
                legend: {
                    position: 'top',
                }
            }
        }
    });
    
    return chart;
}

/**
 * Create a pie chart showing inventory status
 * @param {string} elementId - Canvas element ID
 * @param {Array} statusData - Array of inventory status data
 */
function createInventoryStatusChart(elementId, statusData) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const chart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: statusData.map(item => item.status),
            datasets: [{
                data: statusData.map(item => item.count),
                backgroundColor: [
                    'rgba(255, 193, 7, 0.8)',   // In Japan (warning)
                    'rgba(13, 202, 240, 0.8)',  // In Transit (info)
                    'rgba(13, 110, 253, 0.8)',  // Arrived (primary)
                    'rgba(25, 135, 84, 0.8)',   // Ready for Sale (success)
                    'rgba(108, 117, 125, 0.8)'  // Sold (secondary)
                ],
                borderColor: [
                    'rgba(255, 193, 7, 1)',
                    'rgba(13, 202, 240, 1)',
                    'rgba(13, 110, 253, 1)',
                    'rgba(25, 135, 84, 1)',
                    'rgba(108, 117, 125, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    return chart;
}

/**
 * Create a line chart for expenses over time
 * @param {string} elementId - Canvas element ID
 * @param {Array} expensesData - Array of expense data points
 */
function createExpensesChart(elementId, expensesData) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: expensesData.map(item => item.date),
            datasets: [{
                label: 'Expenses (GBP)',
                data: expensesData.map(item => item.amount),
                fill: false,
                borderColor: 'rgba(220, 53, 69, 1)',
                tension: 0.1,
                pointBackgroundColor: 'rgba(220, 53, 69, 1)',
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '£' + value.toLocaleString();
                        }
                    }
                },
                x: {
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return '£' + context.parsed.y.toLocaleString();
                        }
                    }
                }
            }
        }
    });
    
    return chart;
}

/**
 * Create a horizontal bar chart for expense categories
 * @param {string} elementId - Canvas element ID
 * @param {Array} categoriesData - Array of expense category data
 */
function createExpenseCategoriesChart(elementId, categoriesData) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: categoriesData.map(item => item.name),
            datasets: [{
                label: 'Amount (GBP)',
                data: categoriesData.map(item => item.amount),
                backgroundColor: 'rgba(13, 110, 253, 0.6)',
                borderColor: 'rgba(13, 110, 253, 1)',
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '£' + value.toLocaleString();
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return '£' + context.parsed.x.toLocaleString();
                        }
                    }
                }
            }
        }
    });
    
    return chart;
}

/**
 * Create a doughnut chart showing payment status
 * @param {string} elementId - Canvas element ID
 * @param {number} paidAmount - Amount already paid
 * @param {number} outstandingAmount - Amount still outstanding
 */
function createPaymentStatusChart(elementId, paidAmount, outstandingAmount) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Paid', 'Outstanding'],
            datasets: [{
                data: [paidAmount, outstandingAmount],
                backgroundColor: [
                    'rgba(25, 135, 84, 0.8)',  // Paid (success)
                    'rgba(255, 193, 7, 0.8)'   // Outstanding (warning)
                ],
                borderColor: [
                    'rgba(25, 135, 84, 1)',
                    'rgba(255, 193, 7, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            const total = paidAmount + outstandingAmount;
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: £${value.toLocaleString()} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    
    return chart;
}

/**
 * Create a monthly profit margins chart
 * @param {string} elementId - Canvas element ID
 * @param {Array} profitMarginData - Array of profit margin data points
 */
function createProfitMarginsChart(elementId, profitMarginData) {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: profitMarginData.map(item => item.month),
            datasets: [{
                label: 'Profit Margin (%)',
                data: profitMarginData.map(item => item.percentage),
                fill: true,
                backgroundColor: 'rgba(13, 202, 240, 0.2)',
                borderColor: 'rgba(13, 202, 240, 1)',
                tension: 0.3,
                pointBackgroundColor: 'rgba(13, 202, 240, 1)',
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y.toFixed(1) + '%';
                        }
                    }
                }
            }
        }
    });
    
    return chart;
}

/**
 * Update chart data and re-render
 * @param {Chart} chart - Chart.js instance
 * @param {Array} labels - New labels
 * @param {Array} data - New data points
 */
function updateChartData(chart, labels, data) {
    chart.data.labels = labels;
    chart.data.datasets.forEach((dataset, i) => {
        dataset.data = Array.isArray(data[i]) ? data[i] : data;
    });
    chart.update();
}

/**
 * Initialize dashboard charts
 */
function initDashboardCharts() {
    // Check if we have the necessary data and elements
    if (typeof monthlyProfitData === 'undefined' || 
        typeof monthlySalesData === 'undefined') {
        return;
    }
    
    const financialChart = document.getElementById('financialChart');
    if (financialChart) {
        createSalesVsProfitChart('financialChart', monthlySalesData, monthlyProfitData);
    }
}

// Initialize charts when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    initDashboardCharts();
});
