/**
 * Burraq Motors Management System - Main Scripts
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips and popovers
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Format currency inputs
    var currencyInputs = document.querySelectorAll('.currency-format');
    currencyInputs.forEach(input => {
        input.addEventListener('focus', function() {
            unformatCurrencyValue(this);
        });
        
        input.addEventListener('blur', function() {
            formatCurrencyValue(this);
        });
    });
    
    // Exchange rate fetching for car form
    if (document.getElementById('exchange-rate-btn')) {
        document.getElementById('exchange-rate-btn').addEventListener('click', fetchExchangeRate);
    }
    
    // GBP calculation for car form
    if (document.getElementById('calculate-gbp-btn')) {
        document.getElementById('calculate-gbp-btn').addEventListener('click', calculateGBPValues);
    }
    
    // Payment amount calculation for sale form
    if (document.getElementById('payment-type')) {
        document.getElementById('payment-type').addEventListener('change', calculatePaymentAmount);
        document.getElementById('selling-price').addEventListener('input', calculatePaymentAmount);
    }
});

/**
 * Fetch the current exchange rate from JPY to GBP
 */
async function fetchExchangeRate() {
    try {
        const response = await fetch('/api/exchange-rate');
        const data = await response.json();
        
        if (data.rate) {
            document.getElementById('exchange-rate').value = data.rate;
            // Calculate GBP values if yen values are already entered
            calculateGBPValues();
        }
    } catch (error) {
        console.error('Error fetching exchange rate:', error);
        alert('Failed to fetch current exchange rate. Please enter manually.');
    }
}

/**
 * Calculate GBP values based on Yen values and exchange rate
 */
function calculateGBPValues() {
    const auctionPriceYen = parseFloat(document.getElementById('auction-price-yen').value) || 0;
    const initialPaymentYen = parseFloat(document.getElementById('initial-payment-yen').value) || 0;
    const exchangeRate = parseFloat(document.getElementById('exchange-rate').value) || 0;
    
    if (exchangeRate <= 0) {
        alert('Please enter a valid exchange rate');
        return;
    }
    
    // Calculate GBP values
    const auctionPriceGBP = (auctionPriceYen / exchangeRate).toFixed(2);
    const initialPaymentGBP = (initialPaymentYen / exchangeRate).toFixed(2);
    
    // Display calculated values
    if (document.getElementById('auction-price-gbp-display')) {
        document.getElementById('auction-price-gbp-display').textContent = `£${auctionPriceGBP}`;
    }
    
    if (document.getElementById('initial-payment-gbp-display')) {
        document.getElementById('initial-payment-gbp-display').textContent = `£${initialPaymentGBP}`;
    }
}

/**
 * Calculate the payment amount based on payment type
 */
function calculatePaymentAmount() {
    const sellingPrice = parseFloat(document.getElementById('selling-price').value) || 0;
    const paymentType = document.getElementById('payment-type').value;
    
    let amountReceived = sellingPrice;
    
    if (paymentType === 'Half') {
        amountReceived = sellingPrice / 2;
    }
    
    document.getElementById('amount-received').value = amountReceived.toFixed(2);
}

/**
 * Format currency value for display
 * @param {HTMLInputElement} input - The input element to format
 */
function formatCurrencyValue(input) {
    const value = input.value;
    if (!value || isNaN(parseFloat(value))) return;
    
    // Format to 2 decimal places
    const formattedValue = parseFloat(value).toFixed(2);
    input.value = formattedValue;
}

/**
 * Unformat currency value for editing
 * @param {HTMLInputElement} input - The input element to unformat
 */
function unformatCurrencyValue(input) {
    const value = input.value;
    if (!value) return;
    
    // Remove any formatting to get the raw number
    const numericValue = parseFloat(value);
    if (!isNaN(numericValue)) {
        input.value = numericValue;
    }
}