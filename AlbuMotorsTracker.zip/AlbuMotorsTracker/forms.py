from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, FloatField, DateField, HiddenField, TextAreaField
from wtforms.validators import DataRequired, Email, Length, ValidationError, Optional, EqualTo
from datetime import date

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Sign In')

class CarForm(FlaskForm):
    car_name = StringField('Car Name', validators=[DataRequired()])
    vin = StringField('Vehicle Identification Number (VIN)', validators=[DataRequired()])
    auction_id = StringField('Auction ID')
    
    auction_price_yen = FloatField('Auction Price (¥)', validators=[DataRequired()])
    initial_payment_yen = FloatField('Initial Payment (30%) (¥)', validators=[DataRequired()])
    exchange_rate = FloatField('Exchange Rate (¥ to GBP)', validators=[DataRequired()])
    
    port_charges_gbp = FloatField('Port Charges (GBP)', validators=[DataRequired()])
    inspection_charges_gbp = FloatField('Inspection Charges (GBP)', validators=[DataRequired()])
    final_payment_gbp = FloatField('Final Payment (GBP)', validators=[DataRequired()])
    
    submit = SubmitField('Save Car')

class CustomerForm(FlaskForm):
    name = StringField('Customer Name', validators=[DataRequired(), Length(max=100)])
    contact_info = StringField('Contact Information', validators=[DataRequired()])
    date_of_birth = DateField('Date of Birth', format='%Y-%m-%d', validators=[Optional()])
    submit = SubmitField('Save Customer')

class SaleForm(FlaskForm):
    car_id = SelectField('Car', coerce=int, validators=[DataRequired()])
    customer_id = SelectField('Customer', coerce=int, validators=[DataRequired()])
    selling_price = FloatField('Selling Price (GBP)', validators=[DataRequired()])
    payment_type = SelectField('Payment Type', 
                              choices=[('Full', 'Full Payment'), ('Half', 'Half Payment')], 
                              validators=[DataRequired()])
    amount_received = FloatField('Amount Received (GBP)', validators=[DataRequired()])
    sale_date = DateField('Sale Date', format='%Y-%m-%d', validators=[DataRequired()], default=date.today)
    submit = SubmitField('Record Sale')

class InvoiceForm(FlaskForm):
    sale_id = SelectField('Sale', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Generate Invoice')