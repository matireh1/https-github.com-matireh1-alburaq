from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Car(db.Model):
    __tablename__ = 'cars'
    
    id = db.Column(db.Integer, primary_key=True)
    car_name = db.Column(db.String(100), nullable=False)
    vin = db.Column(db.String(100), nullable=False, unique=True)
    auction_id = db.Column(db.String(100))
    auction_price_yen = db.Column(db.Float, nullable=False)
    initial_payment_yen = db.Column(db.Float, nullable=False)  # 30% payment
    port_charges_gbp = db.Column(db.Float, nullable=False)
    inspection_charges_gbp = db.Column(db.Float, nullable=False)
    final_payment_gbp = db.Column(db.Float, nullable=False)
    exchange_rate = db.Column(db.Float, nullable=False)  # Yen to GBP rate
    
    # Calculated fields
    auction_price_gbp = db.Column(db.Float, nullable=False)
    initial_payment_gbp = db.Column(db.Float, nullable=False)
    total_cost_gbp = db.Column(db.Float, nullable=False)
    
    # Status information
    status = db.Column(db.String(50), default="Available")  # Available, Sold
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sale = db.relationship('Sale', backref='car', lazy=True, uselist=False)
    
    def __repr__(self):
        return f'<Car {self.car_name} - {self.vin}>'

class Customer(db.Model):
    __tablename__ = 'customers'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    contact_info = db.Column(db.String(100))
    date_of_birth = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    sales = db.relationship('Sale', backref='customer', lazy=True)
    
    def __repr__(self):
        return f'<Customer {self.name}>'
    
    def get_remaining_amount(self):
        """Get the total remaining amount to be paid by this customer"""
        total_remaining = 0
        for sale in self.sales:
            if sale.payment_type == 'Half':
                total_remaining += sale.selling_price - sale.amount_received
        return total_remaining

class Sale(db.Model):
    __tablename__ = 'sales'
    
    id = db.Column(db.Integer, primary_key=True)
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    selling_price = db.Column(db.Float, nullable=False)
    payment_type = db.Column(db.String(20), nullable=False)  # Full, Half
    amount_received = db.Column(db.Float, nullable=False)
    sale_date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date())
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Sale {self.id} - {self.car.car_name} to {self.customer.name}>'
    
    def get_remaining_amount(self):
        """Get the remaining amount to be paid for this sale"""
        if self.payment_type == 'Full':
            return 0
        return self.selling_price - self.amount_received
    
    def calculate_profit(self):
        """Calculate the profit from this sale"""
        return self.selling_price - self.car.total_cost_gbp